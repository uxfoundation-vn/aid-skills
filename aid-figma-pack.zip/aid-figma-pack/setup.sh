#!/bin/bash
# Cài pack aid-figma vào Claude Code. Chạy: bash setup.sh
# Giữ nguyên thư mục này sau khi cài: Claude Code đọc pack thẳng từ đây.
# Plugin Figma và các MCP do skill /aid-figma:setup dẫn cài tiếp, từng bước.
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
CLAUDE="$(command -v claude || echo "$CLAUDE_CODE_EXECPATH")"
[ -x "$CLAUDE" ] || { echo "Không thấy lệnh 'claude'. Mở Claude Code và nhờ Claude chạy script này."; exit 1; }

"$CLAUDE" plugin marketplace add "$DIR"
"$CLAUDE" plugin install aid-figma@aid
echo "Xong. Mở session Claude Code mới, gõ /aid-figma:setup để Claude dẫn cài tiếp từng bước."
