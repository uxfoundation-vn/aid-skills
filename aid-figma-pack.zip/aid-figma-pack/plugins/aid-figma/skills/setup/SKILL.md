---
name: setup
description: Cài và kiểm tra pack aid-figma — plugin Figma "Lâyơ ở mố?", MCP Figma desktop, Figma MCP — dẫn người dùng từng bước, xong bước nào xác nhận bước đó rồi mới đi tiếp. Dùng khi người dùng vừa cài pack, gõ "setup", "cài đặt", "cài figma", "kiểm tra pack", hoặc khi skill figma-desktop báo plugin/MCP chưa sẵn sàng.
---

# Setup pack aid-figma

## Cách dẫn
- Mỗi lần chỉ một bước. Trong một tin nhắn: nói bước này để làm gì (một câu), Claude tự chạy phần chạy được, rồi dặn người dùng đúng chỗ bấm (menu → mục → nút), đánh số từng thao tác.
- Phần cần người dùng bấm thì kết thúc tin nhắn bằng câu hỏi xác nhận (dùng AskUserQuestion nếu có: "Xong rồi" / "Bị kẹt"), rồi **dừng chờ**. Không dồn bước sau vào cùng tin nhắn.
- Người dùng báo xong thì Claude **tự kiểm tra** bằng lệnh ở mục "Kiểm tra" của bước đó. Đạt thì báo `✓ Bước N xong` rồi sang bước sau. Chưa đạt thì nói lý do có thể, dặn lại phần bị thiếu, hỏi lại.
- Bắt đầu bằng mục "Dò trạng thái": bước nào đã đạt thì báo ✓ và bỏ qua, không bắt làm lại.
- Cuối cùng in bảng tổng kết 4 dòng: Plugin Lâyơ ở mố? · MCP figma-desktop · Figma MCP · Chạy thử — mỗi dòng ✓ hoặc còn thiếu gì.

## Lệnh dùng chung
- `NAV` = `python3 <thư mục skill này>/../figma-desktop/scripts/nav.py`
- `CLAUDE` = `claude` nếu có trong PATH (`command -v claude`), không thì `"$CLAUDE_CODE_EXECPATH"` (app Claude desktop luôn có biến này).
- Cần `python3`. Chạy `python3 --version`; lỗi hoặc macOS hiện hộp thoại "command line developer tools" thì bảo người dùng bấm Install, chờ xong rồi xác nhận.

## Dò trạng thái
Chạy cùng lúc rồi tóm tắt bước nào đã xong:
- `NAV sel` (lệnh này tự bật server nếu chưa chạy) → có dòng "đang mở" là bước 1 xong.
- `CLAUDE mcp get figma-desktop` có kết quả và `curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:3845/mcp` khác `000` → bước 2 xong.
- `CLAUDE plugin list` có `figma@claude-plugins-official` và `CLAUDE mcp list` báo `figma` ✔ Connected → bước 3 xong.

## Bước 1 · Plugin Figma "Lâyơ ở mố?"
Để làm gì: plugin báo cho Claude biết bạn đang chọn layer nào, và hiện bảng layer Claude đã sửa.
1. Claude chạy `NAV setup`: chép plugin ra `~/Documents/Claude Nav/`, mở Finder ở `manifest.json`, và bật server cục bộ `localhost:3847` (plugin gửi selection lên server này; Claude đọc lại bằng `NAV sel`). Từ giờ mỗi lần mở session Claude Code, pack tự bật server này (hook SessionStart).
2. Dặn người dùng:
   1. Mở app **Figma desktop** (bản web không chạy được plugin development), mở một file design bất kỳ.
   2. Menu Figma → **Plugins** → **Development** → **Import plugin from manifest…** → chọn `~/Documents/Claude Nav/manifest.json`.
   3. Menu Figma → **Plugins** → **Development** → **Lâyơ ở mố?**. Một bảng nhỏ "Layer đã sửa" hiện ra. (Lần sau chạy lại nhanh bằng `Cmd+Opt+P`.)
   4. Chọn một frame bất kỳ.
3. Hỏi xác nhận, dừng chờ.

Kiểm tra: `NAV sel` thấy tên file "đang mở" và đúng frame vừa chọn.

Bảng trên Figma báo đỏ **"Chưa nối được Claude"**: plugin không gọi được server `localhost:3847`.
- Chạy `NAV ensure` (bật server). Bảng tự nối lại trong 1 giây, không cần chạy lại plugin.
- Vẫn đỏ: `curl -s http://127.0.0.1:3847/` phải ra `{"ok":true,"app":"claude-nav"}`. Không ra thì xem `~/.claude/claude-nav.log`; cổng bị app khác chiếm thì `lsof -iTCP:3847 -sTCP:LISTEN` để biết app nào.
- Server ok mà bảng vẫn đỏ: plugin đang chạy là bản import cũ hoặc import nhầm chỗ. Chạy lại `NAV setup`, rồi tắt và chạy lại plugin. Đọc lại cho người dùng: "Mình thấy bạn đang chọn <tên frame> trong <tên file>".

## Bước 2 · MCP Figma desktop
Để làm gì: Claude đọc trực tiếp file đang mở trong Figma desktop (cây layer, ảnh chụp frame, biến màu).
1. Dặn người dùng bật server trong Figma:
   1. Trong Figma desktop, bấm `Shift+D` để vào **Dev Mode**.
   2. Panel **Inspect** bên phải → mục MCP → bật **Enable desktop MCP server**. (Bản Figma cũ: menu Figma → Preferences → Enable Dev Mode MCP Server.)
   3. Cần seat Dev hoặc Full trên gói Figma trả phí. Không thấy nút bật / bị khoá thì báo "Bị kẹt": bỏ qua bước này, vẫn làm được bước 3–4.
2. Hỏi xác nhận, dừng chờ.
3. Người dùng báo xong: kiểm tra `curl` tới `http://127.0.0.1:3845/mcp` khác `000`. Đạt thì Claude tự cài vào Claude Code (bỏ qua nếu `CLAUDE mcp get figma-desktop` đã có):
   `CLAUDE mcp add --scope user --transport http figma-desktop http://127.0.0.1:3845/mcp`

Kiểm tra: `CLAUDE mcp list` có `figma-desktop` ✔ Connected.

## Bước 3 · Figma MCP (để Claude sửa file Figma)
Để làm gì: MCP chính thức của Figma, có tool `use_figma` để sửa layer và skill `figma-use` dạy Claude cách dùng.
1. Claude tự cài (bỏ qua phần đã có):
   - `CLAUDE plugin marketplace add anthropics/claude-plugins-official` (báo đã có thì thôi)
   - `CLAUDE plugin install figma@claude-plugins-official`
2. Dặn người dùng đăng nhập:
   1. Mở **session Claude Code mới** (MCP vừa cài chỉ hiện ở session mới).
   2. Trong session mới gõ `/mcp` → chọn **figma** → **Authenticate** → đăng nhập Figma trên trình duyệt, bấm **Allow access**, quay lại Claude Code.
   3. Vẫn trong session mới, gõ `/aid-figma:setup` để làm tiếp bước 4.
3. Dừng ở đây (session mới sẽ dò trạng thái và đi tiếp).

Kiểm tra (ở session mới): `CLAUDE mcp list` có `figma` ✔ Connected, và tool `use_figma` có trong session.

## Bước 4 · Chạy thử
Để làm gì: thử đúng cách sẽ làm hằng ngày.
1. Dặn người dùng chọn một frame trong file đang chạy plugin, hỏi xác nhận, dừng chờ.
2. `NAV sel` → nói "Mình hiểu bạn đang chọn <tên> trong <file>".
3. Nếu có MCP figma-desktop: `get_screenshot` frame đó, tả ngắn một câu frame có gì.
4. Push thử lên bảng: `NAV push <fileKey> "Thử setup" '[["<id>","<tên frame> · thử"]]' --who "Setup"` → ra `R1`.
5. Dặn người dùng: trên bảng "Layer đã sửa" trong Figma có tab **R1** với một dòng; bấm dòng đó → Figma nhảy tới frame. Hỏi xác nhận, dừng chờ.

Xong thì in bảng tổng kết, rồi nhắc cách dùng: chọn frame → nói "check frame này" / "sửa chỗ này…"; gõ `bảng`, `mở bảng R2`, `mở 3`.
