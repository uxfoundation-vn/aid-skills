# aid-figma — Claude Code làm việc với Figma desktop

Cài xong, bạn chỉ cần **chọn một frame trong Figma rồi nói "sửa cái này"**: Claude tự biết bạn đang chọn gì. Sửa xong, Claude ghi lại danh sách layer đã đụng tới vào một bảng nhỏ ngay trong Figma, bấm vào dòng nào thì Figma nhảy tới layer đó.

## Trong pack có gì

| Thành phần | Làm gì |
|---|---|
| Plugin Figma **"Lâyơ ở mố?"** | Chạy trong Figma desktop: gửi layer đang chọn cho Claude, hiện bảng "Layer đã sửa" R1–R3 |
| Skill `figma-desktop` | Dạy Claude: đọc layer đang chọn làm ngữ cảnh, đẩy bảng sau mỗi lượt sửa, báo cáo ngắn |
| Skill `setup` | Claude dẫn bạn cài từng bước, xong bước nào kiểm tra bước đó: plugin Figma, MCP Figma desktop (đọc file đang mở), Figma MCP (sửa file) |

## Cần có
- macOS, app **Figma desktop** (bản web không chạy được plugin development), Claude Code.
- MCP Figma desktop cần seat Dev hoặc Full trên gói Figma trả phí. Không có thì vẫn dùng được phần chọn layer và sửa qua Figma MCP.

## Cài

1. Giải nén thư mục `aid-figma-pack` vào **Documents** và để yên đó (Claude Code đọc pack thẳng từ thư mục này, xoá đi là mất).
2. Mở Claude Code, gửi câu này:
   ```
   Chạy bash ~/Documents/aid-figma-pack/setup.sh giúp tôi
   ```
   (Hoặc tự chạy lệnh đó trong Terminal.)
3. Mở **session Claude Code mới**, gõ `/aid-figma:setup`. Claude dẫn tiếp từng bước, bạn làm xong bước nào thì báo, Claude kiểm tra rồi mới sang bước sau.

## Dùng hằng ngày

- Mở file Figma → chạy plugin **Lâyơ ở mố?** (`Cmd+Opt+P` chạy lại plugin vừa dùng). Mỗi file phải chạy plugin riêng.
- Chọn frame / layer → nói với Claude: "check frame này", "sửa chỗ này cho …", "cái này đang dùng màu nào".
- Sau mỗi lượt sửa, Claude báo ngắn + bảng `Layer · <tên file> · R1`. Trong Figma, bảng hiện R1–R3 (3 lượt gần nhất); bấm từng dòng để nhảy tới layer.
- Gõ tắt trong chat: `bảng` (mở bảng lượt mới nhất), `mở bảng R2`, `mở 3` (nhảy tới layer số 3).
- Có gì không chạy: gõ `/aid-figma:setup`, Claude dò lại và chỉ chỗ thiếu.
